# NativeScript Theme: Core

Core NativeScript theme including a light (default), dark, and (11 additional: aqua, blue, brown, forest, grey, lemon, lime, orange, purple, ruby, sky) color schemes for iOS and Android.

## Install

`npm install nativescript-theme-core --save`

## Documentation

http://docs.nativescript.org/ui/theme

## Preview

![Multiple Platforms](http://docs.nativescript.org/img/theme/color-schemes-all.png)

## License

This is Licensed under the Apache License 