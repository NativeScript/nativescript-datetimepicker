module.exports = function ($usbLiveSyncService) {
    $usbLiveSyncService.forceExecuteFullSync = false;
};
