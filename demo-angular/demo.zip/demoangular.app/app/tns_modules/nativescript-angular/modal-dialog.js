Object.defineProperty(exports, "__esModule", { value: true });
var dialogs_1 = require("./directives/dialogs");
exports.ModalDialogHost = dialogs_1.ModalDialogHost;
exports.ModalDialogParams = dialogs_1.ModalDialogParams;
exports.ModalDialogService = dialogs_1.ModalDialogService;
//# sourceMappingURL=modal-dialog.js.map