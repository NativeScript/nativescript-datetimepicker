Object.defineProperty(exports, "__esModule", { value: true });
require("../platform");
require("./dist/zone-nativescript.mocha.js");
//# sourceMappingURL=testing.mocha.js.map