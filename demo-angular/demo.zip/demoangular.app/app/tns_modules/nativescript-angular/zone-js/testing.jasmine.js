Object.defineProperty(exports, "__esModule", { value: true });
// Bootstrap helper module for jasmine spec tests
require("../platform");
require("./dist/zone-nativescript.jasmine.js");
//# sourceMappingURL=testing.jasmine.js.map